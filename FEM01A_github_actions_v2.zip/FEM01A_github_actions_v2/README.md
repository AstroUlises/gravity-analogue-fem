# FEM-01/A GitHub Actions runner — blind benchmark

This repository payload executes the preregistered FEM-01/A Partovi–Morris benchmark without embedding the hidden reference-force table.

## Scientific status
- Target: validate Elmer/Gmsh against the uniform conducting-pipe benchmark before allowing the solver to see Schwarzschild or Painleve-Gullstrand profiles.
- Acceptance criterion remains hidden from solver tuning and is evaluated only after the blind result is frozen.
- The separate reference package is **not** part of this repository payload.

## Reproducibility choices
- Runner: `ubuntu-24.04`.
- Elmer: compiled from official `ElmerCSC/elmerfem` at pinned commit `6cc96530bbfd7fa1cb8803f4cae878461cd2c1e1`.
- Gmsh: Ubuntu runner package, with exact version recorded in `provenance.json`.
- Elmer install is cached, but the cache key includes the pinned commit.
- `OMP_NUM_THREADS=1` to reduce nondeterministic threading effects during the first gate.

## Workflow
`.github/workflows/fem01a_blind.yml`

It performs:
1. dependency installation;
2. pinned Elmer build/cache;
3. static blind-data checks;
4. three complete mesh sweeps (`MeshScale = 1.4, 1.0, 0.7`);
5. freezing of the fine-mesh output and SHA-256;
6. artifact upload containing outputs, logs, hashes, and provenance.

## Blindness rule
Do **not** add `reference_PM.csv` or the separate `reference_key` folder before the workflow has finished and `fem_raw_FROZEN.csv.sha256` has been recorded.

Only after freezing, compare externally using the separate key package.

## GitHub connection status in the originating chat
The connected GitHub installation exposed zero writable repositories, so this payload was not pushed or executed from ChatGPT. Once a repository is connected, copy this directory at repository root and trigger **FEM-01A blind Partovi-Morris benchmark** manually (or by push).
